# Voice Assistant Project

A simple Python voice assistant that can:

- Tell the current time and date
- Analyze your mood based on your speech
- Tell current weather (default: Haldwani, Uttarakhand)
- Read out latest news headlines
- Respond to voice commands

## How to Run

1. Install requirements:

```bash
pip install -r requirements.txt
```

2. Run the assistant:

```bash
python main.py
```

Press `Ctrl+C` or say "exit" to quit.

## Note

- Make sure your microphone is working.
- Replace API keys in `main.py` with your own keys.
