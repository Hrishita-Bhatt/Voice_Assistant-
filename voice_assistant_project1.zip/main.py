import speech_recognition as sr
import pyttsx3
import datetime
import requests
from textblob import TextBlob

# Initialize the speech engine
engine = pyttsx3.init()
engine.setProperty('rate', 180)  # Speed of speech
engine.setProperty('volume', 1)  # Volume (0.0 to 1.0)

# Function to speak text
def speak(text):
    print(f"Assistant: {text}")  # For debugging and visibility
    engine.say(text)
    engine.runAndWait()

# Function for speech recognition
def listen():
    recognizer = sr.Recognizer()
    with sr.Microphone() as source:
        print("Listening for your command...")
        recognizer.adjust_for_ambient_noise(source, duration=1)  # Adjust for background noise
        try:
            audio = recognizer.listen(source, timeout=5, phrase_time_limit=10)
            command = recognizer.recognize_google(audio)
            print(f"You said: {command}")
            return command.lower()
        except sr.WaitTimeoutError:
            speak("I didn't hear anything. Please try again.")
            return None
        except sr.UnknownValueError:
            speak("Sorry, I couldn't understand what you said.")
            return None
        except sr.RequestError:
            speak("I'm having trouble connecting. Please check your internet.")
            return None

# Function to get the current time and date
def get_time_and_date():
    now = datetime.datetime.now()
    time = now.strftime("%I:%M:%S %p")  # 12-hour format with AM/PM
    date = now.strftime("%Y-%m-%d")
    speak(f"The time is {time} and today's date is {date}")

# Function to analyze sentiment and predict mood
def predict_mood():
    speak("Please tell me something, and I will analyze how you're feeling.")
    user_input = listen()
    if user_input:
        blob = TextBlob(user_input)
        sentiment = blob.sentiment.polarity
        if sentiment > 0:
            speak("You sound happy and in a good mood today!")
        elif sentiment < 0:
            speak("You might be feeling a bit sad or down. I hope you feel better soon.")
        else:
            speak("You seem neutral today, not too happy and not too sad.")
    else:
        speak("I couldn't understand what you said. Could you try again?")

# Function to get the weather
def get_weather():
    api_key = "e2c23cfee1f83f0bf74aee0876611234"  # Replace with your OpenWeatherMap API key
    city = "Haldwani,Uttarakhand"
    url = f"http://api.openweathermap.org/data/2.5/weather?q={city}&appid={api_key}&units=metric"
    response = requests.get(url)
    weather_data = response.json()

    if weather_data["cod"] == 200:
        temperature = weather_data["main"]["temp"]
        description = weather_data["weather"][0]["description"]
        speak(f"The current temperature is {temperature}°C with {description}.")
    else:
        speak("I couldn't fetch the weather data.")

# Function to fetch the latest news
def get_news():
    news_api_key = "f024e9cd4caf47f3ab4da7101d4671f7"  # Replace with your News API key
    url = f"https://newsapi.org/v2/top-headlines?country=us&apiKey={news_api_key}"
    response = requests.get(url)
    news_data = response.json()

    if news_data["status"] == "ok":
        for i, article in enumerate(news_data["articles"][:5]):  # Limit to first 5 news
            title = article["title"]
            print(f"News {i + 1}: {title}")  # Print for debugging
            speak(f"News number {i + 1}: {title}")
    else:
        speak("Sorry, I couldn't fetch the news.")

# Main loop for the assistant
def main():
    speak("Hello, I am your voice assistant. How can I assist you today?")
    
    while True:
        command = listen()

        if command is None:
            continue
        
        if 'time' in command or 'date' in command:
            get_time_and_date()
        
        elif 'weather' in command:
            get_weather()

        elif 'news' in command:
            get_news()
        
        elif 'mood' in command or 'sentiment' in command:
            predict_mood()
        
        elif 'exit' in command or 'quit' in command:
            speak("Goodbye! Have a nice day.")
            break
        
        else:
            speak("I'm sorry, I didn't understand that. Please try again.")

if __name__ == "__main__":
    main()
